summary.Mort1Dsmooth <-
function(object, ...){
  class(object) <- "summary.Mort1Dsmooth"
  object
}
