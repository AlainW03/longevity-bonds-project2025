summary.Mort2Dsmooth <-
function(object, ...){
  class(object) <- "summary.Mort2Dsmooth"
  object
}
